// Desc : first cpp hello world program
// Date : 05 jul 2023

#include <iostream>
using namespace std;

int main()
{
    cout << "---------------------------------------------------------" << endl;

    cout << "Hello World";

    cout << endl
         << "---------------------------------------------------------" << endl;
    return 0;
}